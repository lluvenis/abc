package main

import (
	"pkg/logging"
	"pkg/setting"
	"service"
	"task"
)

func init() {
	setting.Setup()
	logging.Setup()
}

func main() {
	logging.Info("############## Start Test file Transform #################")
	defer logging.Info("############## End Test file Transform #################")

	filename, err := service.GetImportFileName()
	if err != nil {
		logging.Error(err)
		//os.Exit(1)
	}

	if err := task.TransformFile(filename); err == nil {
		logging.Info(filename + " : file transform success")
	}
}

package main

import (
	"flag"
	"fmt"
	"os"
	"pkg/logging"
	"pkg/setting"
	"service"
	"strings"
	"task"
)

// Create a new type for a list of Strings
type stringList []string

// Implement the flag.Value interface
func (s *stringList) String() string {
	return fmt.Sprintf("%v", *s)
}

func (s *stringList) Set(value string) error {
	*s = strings.Split(value, ",")
	return nil
}

func init() {
	setting.Setup()
	logging.Setup()
}

func main() {
	// Subcommands
	runCommand := flag.NewFlagSet("run", flag.ExitOnError)

	// Verify that a subcommand has been provided
	if len(os.Args) < 2 {
		fmt.Println("run subcommand is required")
		os.Exit(1)
	}

	// Switch on the subcommand
	switch os.Args[1] {
	case "run":
		runCommand.Parse(os.Args[2:])
	default:
		flag.PrintDefaults()
		os.Exit(1)
	}

	// Check which subcommand was Parsed using the FlagSet.Parsed() function. Handle each case accordingly.
	if runCommand.Parsed() {
		logging.Info("############## Start Test file Transform #################")
		defer logging.Info("############## End Test file Transform #################")

		filename, err := service.GetImportFileName()
		if err != nil {
			fmt.Println(err)
			logging.Error(err)
			//os.Exit(1)
		}

		// run sms file transform task
		if err := task.TransformFile(filename); err == nil {
			logging.Info(filename + " : file transform success")
		}
	}
}
